// clase padre
public class Mensaje {
    public void imprimirMensaje() {
        System.out.println("Este es un mensaje de la clase padre.");
    }
}
