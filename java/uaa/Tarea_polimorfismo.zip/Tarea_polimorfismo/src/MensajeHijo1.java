// clase Hija 1
public class MensajeHijo1 extends Mensaje {
    @Override
    public void imprimirMensaje() {
        System.out.println("Este es el mensje de la clase hija 1.");
    }
}