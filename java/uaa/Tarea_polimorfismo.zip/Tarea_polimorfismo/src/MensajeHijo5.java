// Clase Hija 5
public class MensajeHijo5 extends Mensaje {
    @Override
    public void imprimirMensaje() {
        System.out.println("Este es el mensaje de la clase hija 5.");
    }
}
