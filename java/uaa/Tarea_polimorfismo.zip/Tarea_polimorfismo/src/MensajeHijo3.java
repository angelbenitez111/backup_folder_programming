// Clase Hija 3
public class MensajeHijo3 extends Mensaje {
    @Override
    public void imprimirMensaje() {
        System.out.println("Este es el mensaje de la clase hija 3");
    }
}
